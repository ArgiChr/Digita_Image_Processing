import cv2
import matplotlib.pyplot as plt
import numpy as np
from resize import ResizeWithAspectRatio

# Read / Show an image
image = cv2.imread('../london.jpg') # this image is in BGR format

# Resize using my own resize function
image = ResizeWithAspectRatio(image, height=400)

# Convert image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
print('Initial dimensions', gray_image.shape[0], 'X', gray_image.shape[1])
cv2.imshow("Original Grayscale Image", gray_image)


# Make border to the image
#gray_image = cv2.copyMakeBorder(gray_image, 2, 2, 2, 2, cv2.BORDER_CONSTANT, value=0)
#gray_image = cv2.copyMakeBorder(gray_image, 2, 2, 2, 2, cv2.BORDER_REPLICATE)
#gray_image = cv2.copyMakeBorder(gray_image, 120, 120, 120, 120, cv2.BORDER_REFLECT)
#print('New dimensions', gray_image.shape[0], 'X', gray_image.shape[1])
#cv2.imshow('padded',gray_image)


# Filtering an image using known kernel
kernel = np.ones((5,5),np.float32)/25 #this is a smoothing filter
filtered_img = cv2.filter2D(src=gray_image, ddepth=-1, kernel = kernel,borderType=cv2.BORDER_REFLECT)
#res = np.hstack((gray_image, filtered_img))
#cv2.imshow('Filter with Kernel', res)
#
# Filtering an image using blur (normalized box filter)
blur = cv2.blur(src=gray_image, ksize=(5,5),borderType=cv2.BORDER_REFLECT)
cv2.imshow('Blur', blur)
#
# Filtering an image using box filter (normalized or not box filter)
box = cv2.boxFilter(src=gray_image, ddepth=-1,ksize=(25,25), normalize=True, borderType=cv2.BORDER_REFLECT)
cv2.imshow('Box', box)
#
# Filtering an image using Gaussian blur
gaussian_blur = cv2.GaussianBlur(src=gray_image, ksize=(51,51), sigmaX=9, sigmaY=9,borderType=cv2.BORDER_REFLECT)
cv2.imshow('Gaussian Blur', gaussian_blur)
#
#
# # HighPass Filters
#
# Sobel
sobelx = cv2.Sobel(src=gray_image, ddepth=cv2.CV_64F, dx=1, dy=0, ksize=3)
sobely = cv2.Sobel(src=gray_image, ddepth=cv2.CV_64F, dx=0, dy=1, ksize=3)
sobelxy = cv2.Sobel(src=gray_image, ddepth=cv2.CV_64F, dx=1, dy=1, ksize=3)
#
res = np.hstack((gray_image, sobelx, sobely, sobelxy))
cv2.imshow('Sobel Filter', res)
#
#
# Laplacian filter
laplacian_img = cv2.Laplacian(src=gray_image, ddepth = cv2.CV_64F, borderType=cv2.BORDER_REFLECT)
cv2.imshow('Laplacian', laplacian_img)

# Exit the program by closing all windows
cv2.waitKey(0)
cv2.destroyAllWindows()
