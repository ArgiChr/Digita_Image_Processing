import cv2
import matplotlib.pyplot as plt
import numpy as np

# Read / Show an image
image = cv2.imread('../dogs.jpeg') # this image is in BGR format
# Convert image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)


# creating a Histogram Equalization of an image
equalized_img = cv2.equalizeHist(gray_image)


new_image = cv2.hconcat((gray_image,equalized_img))
cv2.imshow("RESULTS",new_image)

# show image input vs output
histr_gray = cv2.calcHist([gray_image],[0],None,[256],[0,256])
histr_equalized = cv2.calcHist([equalized_img],[0],None,[256],[0,256])
#plt.plot(histr_gray)
#plt.plot(histr_equalized)
#plt.show()

#
#Adaptive Histogram Equalization (no noise boost)
clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(20, 20))
equalized_clahe = clahe.apply(gray_image)
#
res = np.hstack((gray_image, equalized_img, equalized_clahe))
cv2.imshow('Histogram Equalization', res)
#
#
#

# Exit the program by closing all windows
cv2.waitKey(0)
cv2.destroyAllWindows()
