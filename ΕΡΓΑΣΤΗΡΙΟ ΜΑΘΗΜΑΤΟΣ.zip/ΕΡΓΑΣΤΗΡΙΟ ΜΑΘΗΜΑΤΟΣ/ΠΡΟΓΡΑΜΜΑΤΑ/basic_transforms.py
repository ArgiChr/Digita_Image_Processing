import cv2
import matplotlib.pyplot as plt
import numpy as np
from resize import ResizeWithAspectRatio


# Read / Show an image
image = cv2.imread('../london.jpg') # this image is in BGR format
cv2.imshow("Original Image", image)

# Resize an image
#res_image = cv2.resize(image, (100,50))
image = ResizeWithAspectRatio(image, width=None, height=500, inter=cv2.INTER_AREA)
cv2.imshow("Resized image",image)
#
# # See the dimensions of the image
print(f"The image has: {image.shape[0]} rows and {image.shape[1]} columns. It also has {image.shape[2]} colors")
#
# We can select slices of this image using slicing tools
init_x, init_y = 100,100
width, height = 50,50
ROI = image[init_x:init_x+height, init_y:init_y+width]
cv2.imshow("ROI", ROI)
#
 # Convert to RGB
 # This is necessary only when using image with matplotlib, PIL, skimage packages.
image_RGB = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
#cv2.imshow("RGB Image", image_RGB)
#plt.imshow(image)
#plt.show()
#
# Convert image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
cv2.imshow("Gray scale image", gray_image)
#
# Basic intensity transforms
#
# Negative transform
neg_image = 255 - gray_image
#
# Logarithmic
c = 255/(np.log(1+np.max(gray_image)))
log_image = c*np.log(1+gray_image)
log_image = np.array(log_image, dtype=np.uint8)
cv2.imshow("Log image", log_image)
#
# Gamma correction
gamma = 0.3
gamma_corrected = 255*(gray_image/255) ** gamma
gamma_corrected = np.array(gamma_corrected, dtype=np.uint8)
cv2.imshow("Gamma corrected", gamma_corrected)
#
# transform the intensity values of the image into a new range [fmin,fmax]
fmin, fmax = 100,160
new_image = ((gray_image-np.min(gray_image))/(np.max(gray_image)-np.min(gray_image)))*(fmax-fmin)+fmin
new_image = np.array(new_image,dtype=np.uint8)
cv2.imshow("Transformed Image",new_image)
print(f"Original Image: Minimum intensity: {np.min(gray_image)}, Maximum intensity: {np.max(gray_image)}")
print(f"Transformed Image: Minimum intensity: {np.min(new_image)}, Maximum intensity: {np.max(new_image)}")
#
# Contrast estimation
i_max = np.max(gray_image)
i_min = np.min(gray_image)
Contrast = (i_max-i_min)/(i_max+i_min)
print(f"The contrast of the original image is: {Contrast}")
i_max = np.max(new_image)
i_min = np.min(new_image)
Contrast = (i_max-i_min)/(i_max+i_min)
print(f"The contrast of the transformed image is: {Contrast}")
#
# # Show the results
# #new_image = cv2.hconcat((gray_image, log_image, gamma_corrected))
# #cv2.imshow("RESULTS",new_image)
#
#
#
# Histograms
#
histr = cv2.calcHist([gray_image],[0],None,[256],[0,256])
plt.plot(histr)
plt.show()
#
# #color histogram BGR - MUST use this order of the colors for Opencv
# color = ('b','g','r')
# for i, col in enumerate(color):
#     histr = cv2.calcHist([image],[i],None,[256],[0,256])
#     plt.plot(histr,color = col)
#     plt.xlim([0,256])
# #plt.show()
#
# # Contrast Stretching
# import cv2
# import numpy as np
#
# # Function to map each intensity level to output intensity level.
# def pixelVal(pix, r1, s1, r2, s2):
#     if (0 <= pix and pix <= r1):
#         return (s1 / r1)*pix
#     elif (r1 < pix and pix <= r2):
#         return ((s2 - s1)/(r2 - r1)) * (pix - r1) + s1
#     else:
#         return ((255 - s2)/(255 - r2)) * (pix - r2) + s2
# # Define parameters.
# r1,s1 = 70,0
# r2,s2 = 140,255
#
# # Vectorize the function to apply it to each value in the Numpy array.
# pixelVal_vec = np.vectorize(pixelVal)
#
#
#
#
#
# # Apply contrast stretching.
# contrast_stretched = pixelVal_vec(gray_image, r1, s1, r2, s2)
# cv2.imshow("Contrast Stretched",contrast_stretched)
#
#
#
 # Exit the program by closing all windows
cv2.waitKey(0)
cv2.destroyAllWindows()
